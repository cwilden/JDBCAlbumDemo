PREP WORK

Step 1: 
   Right click project > Build path > Configure Build Path
   Update Java JDK.

Step 2:
    Update URL, username, and password in com.utilities.DbCon

Step 3:
    Go to com.ilp.dal.AlbumDao and copy SQLs from the comments and paste them into SQL Developer and run them.
    
